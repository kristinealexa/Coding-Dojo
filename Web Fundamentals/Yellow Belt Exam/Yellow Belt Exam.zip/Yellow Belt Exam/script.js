function custom() {
    console.log("Your cart is empty");
}

function hide(element) {
    element.remove();
}