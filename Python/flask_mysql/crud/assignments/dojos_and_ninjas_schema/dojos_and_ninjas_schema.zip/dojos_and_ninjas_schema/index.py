arr = []

print("before append:", arr)

arr.append("Kristine")
arr.append("Bob")
arr.append("Antoine")

print("after append:", arr)

arr.remove("Bob")
print("after append:", arr)