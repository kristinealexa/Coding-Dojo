from flask import Flask, render_template, redirect, request
from models.user_model import User


app = Flask(__name__)
app.secret_key = 'secret'

@app.route('/read')
def index():
    all_users = User.get_all()
    return render_template("read.html", all_users = all_users)

# @app.post('/add')
# def add():
#     return redirect("/create")

@app.post('/process')
def process():
    User.save(request.form)
    return redirect("/read")

@app.route('/create')
def create():
    return render_template("create.html")

# @app.route('/home')
# def index():
#     return 

if __name__ == "__main__":
    app.run(debug=True)
