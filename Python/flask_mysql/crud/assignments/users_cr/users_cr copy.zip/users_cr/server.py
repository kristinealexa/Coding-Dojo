from flask import Flask, render_template, redirect, request
from models.user_model import User


app = Flask(__name__)
app.secret_key = 'secret'

@app.route('/read')
def index():
    all_users = User.get_all()
    return render_template("read.html", all_users = all_users)

# @app.post('/add')
# def add():
#     return redirect("/create")

@app.post('/process')
def process():
    User.save(request.form)
    return redirect("/read")

@app.route('/create')
def create():
    return render_template("create.html")

@app.route('/read/show/<int:user_id>')
def show(user_id):
    user=User.get_one(user_id)
    return render_template("show_user.html",user=user)

@app.route('/update_form/<int:user_id>')
def update_form(user_id):
    user=User.get_one(user_id)
    return render_template("update.html", user=user)

@app.route('/update',methods=['POST'])
def update():
    User.update(request.form)
    return redirect('/read')

# Delete
@app.route('/read/delete/<int:read_id>')
def read(read_id):
    User.delete(read_id)
    return redirect('/read')

# @app.route('/home')
# def index():
#     return 

if __name__ == "__main__":
    app.run(debug=True)
