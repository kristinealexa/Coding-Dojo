import { useEffect, useState } from 'react';
import { Link, RouterProvider } from 'react-router-dom';
import axios from 'axios'

const Main = (props) => {

    const [products,setProducts] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then(res => {
                console.log(res.data);
                setProducts(res.data);
            })
            .catch(err => {
                console.log(err);
            });
    },[])

    const deleteThis= (deleteId) => {
        console.log("delete", deleteId);
        axios.delete("http://localhost:8000/api/products/" + deleteId)
        .then(res => {
            console.log(res.data);
            const filteredProducts = products.filter((eachProduct) => {
                return eachProduct._id !== deleteId;
            });
            setProducts(filteredProducts);
        })
        .catch(err => console.log(err));
    }

    return (
    <div>
        <p>
          {/* {JSON.stringify(products)} */}
        <h1>All Products:</h1>
        </p>
            {
                products == null ? 'loading':(
                products.map((oneProduct) => {
                    return (
                        <div key={oneProduct._id}>
                            <Link to={"/products/" + oneProduct._id}>
                            <h3>{oneProduct.title}</h3>
                            </Link>
                            <h3>Price: {oneProduct.price}</h3>
                            <h3>Description: {oneProduct.description}</h3>
                            <Link to={`/products/${oneProduct._id}/update`}>Update/Edit this Product</Link>
                            <br/>
                            <button onClick={() => deleteThis(oneProduct._id)}>DELETE</button>
                            <hr />
                        </div>
                    );
                }))
            }
    </div>
    )
}

export default Main