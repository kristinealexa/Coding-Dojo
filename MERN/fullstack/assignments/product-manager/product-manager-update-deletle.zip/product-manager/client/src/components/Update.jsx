import {useState, useEffect} from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Update = (props) => {
    const navigate = useNavigate();

    const { id } = useParams();

    const [title, setTitle] = useState("");
    const [price, setPrice] = useState(1);
    const [description, setDescription] = useState("");


    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + id)
        .then(res =>{
            console.log(res.data);
            setTitle(res.data.title)
            setPrice(res.data.price)
            setDescription(res.data.description)
        })
        .catch(err => console.log(err));
    }, [id]);

    const sumbitHandler = (e) => {
        e.preventDefault();
        console.log("hello");
        const tempObjToSendToDB = {
            title,
            price,
            description
        };

        axios.patch("http://localhost:8000/api/products/" + id, tempObjToSendToDB )
            .then(res => {
                console.log("👍🏼👍🏼👍🏼👍🏼", res.data);
                navigate("/");
            })
            .catch(err => console.log("👎🏼👎🏼👎🏼👎🏼", err));
    };

    return (
        <div>
            <form onSubmit={sumbitHandler}>
                <div>
                    title:
                    <input value={title} onChange={e => setTitle(e.target.value)} />
                </div>
                <div>
                    price:
                    <input type="number" value={price} onChange={e => setPrice(e.target.value)}/>
                </div>
                <div>
                    description:
                    <input value={description} onChange={e => setDescription(e.target.value)}/>
                </div>
                <button>create</button>
            </form>
        </div>
    )
}

export default Update