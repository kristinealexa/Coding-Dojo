import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Create = (props) => {

    const navigate = useNavigate();

    const [title, setTitle] = useState("");
    const [price, setPrice] = useState(1);
    const [description, setDescription] = useState("");

    const sumbitHandler = (e) => {
        e.preventDefault();
        console.log("hello");
        const tempObjToSendToDB = {
            title,
            price,
            description
        };
        axios.post("http://localhost:8000/api/products", tempObjToSendToDB )
            .then(res => {
                console.log("👍🏼👍🏼👍🏼👍🏼", res.data);
                navigate("/");
            })
            .catch(err => console.log("👎🏼👎🏼👎🏼👎🏼", err));
    };

    return (
        <div>
            <form onSubmit={sumbitHandler}>
                <div>
                    title:
                    <input value={title} onChange={e => setTitle(e.target.value)} />
                </div>
                <div>
                    price:
                    <input type="number" value={price} onChange={e => setPrice(e.target.value)}/>
                </div>
                <div>
                    description:
                    <input value={description} onChange={e => setDescription(e.target.value)}/>
                </div>
                <button>create</button>
            </form>
        </div>
    )
}

export default Create