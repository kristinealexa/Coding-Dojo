import { useState } from 'react';
import axios from 'axios';

const Create = (props) => {

    const [title, setTitle] = useState("")
    const [price, setPrice] = useState(1)
    const [description, setDescription] = useState("")

    return (
        <div>
            <form>
                <div>
                    title:
                    <input vaule={title} onChange={e => setTitle(e.target.value)} />
                </div>
                <div>
                    price:
                    <input type="number" value={price} onChange={e => setPrice(e.target.value)}/>
                </div>
                <div>
                    description:
                    <input vaule={description} onChange={e => (e.target.value)}/>
                </div>
                <button>create</button>
            </form>
        </div>
    )
}

export default Create