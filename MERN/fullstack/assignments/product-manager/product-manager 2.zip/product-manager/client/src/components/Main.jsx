import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios'

const Main = (props) => {

    const [products,setProducts] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then(res => {
                console.log(res.data);
                setProducts(res.data);
            })
            .catch(err => {
                console.log(err);
            });
    },[])


    return (
    <div>
        <p>
          {/* {JSON.stringify(products)} */}
        <h1>All Products:</h1>
        </p>
            {
                products == null ? 'loading':(
                products.map((oneProduct) => {
                    return (
                        <div key={oneProduct._id}>
                            <Link to={"/products/" + oneProduct._id}>
                            <h3>{oneProduct.title}</h3>
                            </Link>
                            <h3>Price: {oneProduct.price}</h3>
                            <h3>Description: {oneProduct.description}</h3>
                        </div>
                    );
                }))
            }
    </div>
    )
}

export default Main