import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const OneProduct = (props) => {

    const { id } = useParams();
    const [thisProduct, setThisProduct] = useState(null);

    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + id)
        .then(res =>{
            console.log(res.data);
            setThisProduct(res.data);
        })
        .catch(err => console.log(err));
    }, [id])

    return (
    <div>
        {/* {JSON.stringify(thisProduct)} */}
        {
            thisProduct ? (
                <>
                    <h2>{thisProduct.title}</h2>
                    <h2>{thisProduct.price}</h2>
                    <h2>{thisProduct.description}</h2>
                </>
                ): <h3>Loading...</h3>
        }
    </div>
    );
};

export default OneProduct