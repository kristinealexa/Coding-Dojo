import './App.css';
import {Routes, Route, Link} from 'react-router-dom';
import Main from './components/Main';
import OneProduct from './components/OneProduct';
import Create from './components/Create';

function App() {
  return (
    <div className="App">
      <h1>Product Manager</h1>
      <Link to="/products/create">Create form</Link> <br></br>
      <Link to="/">Home</Link>


      <Routes>

      {/* DASHBOARD*/}
      <Route path='/' element={<Main />}/>

      {/* READ ONE */}
      <Route path='/products/:id' element={<OneProduct/>}/>

      {/* CREATE  */}
      <Route path='/products/create' element={<Create/>}/>  
      </Routes>

    </div>
  );
}

export default App;
