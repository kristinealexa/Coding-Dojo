//variables rider must have to ride rollercoaster
var minimumAge = 10
var minimumHeight = "42 inches"