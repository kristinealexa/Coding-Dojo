
    function greeting(sayGreeting){
        return "Hello World";
    }
    var word = greeting("say hello world");
    console.log(greeting);