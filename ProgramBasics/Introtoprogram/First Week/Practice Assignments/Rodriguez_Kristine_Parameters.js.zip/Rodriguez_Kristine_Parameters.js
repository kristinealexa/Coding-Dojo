function greet(person) {
    console.log('Good day, Kristine!');
}
greet('Kristine');

function greet(person, timeOfDay) {
    console.log('Good morning, Kristine!')
}
greet('Kristine');

function greet(person, timeOfDay) {
    if (person === "Count Dooku") {
        console.log("I'm coming for you, Dooku!")
    } else {
        console.log('Good morning,Kristine');
    }
}