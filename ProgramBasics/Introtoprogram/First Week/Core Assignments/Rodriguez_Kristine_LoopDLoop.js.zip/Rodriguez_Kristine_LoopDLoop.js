//we need a loop to figure out how many miles are ran for a piece of candy to pop out
//starting point should be 0 for distance of miles ran
//loop should stop when it reaches 6 miles
//loop will stop when condition is no longer true
//the incrementing for each iteration would be 2
//variables needed would be distance ran and candy popping out

var distanceRan = 0
//var candyPopOut= 2 miles

for (var milesStartingAt=0; distanceRan<=6; candyPopOut++2) {
{ console.log(distanceRan)
}
} 
//need review please, getting confused with loops